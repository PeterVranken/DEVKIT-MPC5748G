README for GRB-29030_B.zip

Company Part Number: 170-29030 REV B

Date: Mon, 27 Jun 2016 15:00:52 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

CAD Manager
===========
Company Contact     : Daniel Kruczek
Work Phone          : 512-895-6081
Email               : daniel.kruczek@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Jorge Garcia
Work Phone          : +52(33)3283-2309
Email               : jorge.garcia1@nxp.com

Product Engineer
================
Company Contact     : Alfredo Alvarez
Work Phone          : +52(33)3283-2100x2231
Email               : alfredo.alvarez1@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Andres Marquez
Work Phone          : +52(33) 3283-2100 x3068
Email               : andres.marquez@nxp.com
